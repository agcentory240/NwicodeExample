<?php
$init = function($bootstrap) {
	//Somw functions can be here
};