<?php

class NwicodeExample_Model_Db_Table_NwicodeExample extends Core_Model_Db_Table
{
    protected $_name = "nwicodeexample";
    protected $_primary = "nwicodeexample_id";

}