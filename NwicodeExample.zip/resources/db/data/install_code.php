<?php

	// Here you can put the code that will be executed after creating or making changes to the application tables at the module installation stage.





