﻿# Example module for NWICODE CMS
**Версия 1.0.0:**

Пример модуля для конструктора мобильных приложений NWICODE / Module example for NWICODE CMS

